import "dotenv/config";
import Fastify from "fastify";

const app = Fastify({ logger: true });

app.get("/", async () => {
  return { status: "ok", app: "ingresso" };
});

app.listen({
  port: Number(process.env.PORT || 3333),
  host: "0.0.0.0",
}).then(() => {
  console.log("API rodando");
});
